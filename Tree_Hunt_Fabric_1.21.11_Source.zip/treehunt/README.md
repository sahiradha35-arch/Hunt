# Tree Hunt (Fabric / Minecraft Java 1.21.11)

**Gameplay:** break 5 recognized log blocks to trigger a hunt. A named Vex (“Tree Ghost”) spawns and targets the player. Plant 10 saplings nearby (the mod scans a 25×11×25 area every 10 ticks) to end the hunt and remove tracked ghost entities.

## Build
- Install Java 21 and Gradle (or use a Gradle wrapper from a standard Fabric template).
- Open this folder as a Gradle project in IntelliJ IDEA.
- Run `gradle build` (Gradle downloads Minecraft/Fabric dependencies; internet required).
- Output JAR will be in `build/libs/`.

Target: Minecraft 1.21.11, Fabric Loader 0.18.1, Fabric API 0.141.1+1.21.11, Loom 1.14.1.

## Notes / first test
This is an initial source build, not a compiled/tested JAR. Sapling detection is proximity-based and may count pre-existing saplings that are first detected during the hunt. Ghost behavior uses the vanilla Vex mob. Test in a throwaway world first.
